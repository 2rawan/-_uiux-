# Screen and prototype inventory

## Good morning, Olivia (overview)
Section: Start · Type: dashboard

A calm command center for today's virtual office, upcoming sessions, and attendance exceptions.

- Open virtual office → office
- View weekly schedule → schedule
- Review attendance → attendance-report
- Manage members → members
- Open recordings → recordings
- Messages and channels → messages-inbox
- Customize avatar and office → avatar-theme
- Connect calendar → calendar-connect
- AI meeting notes → ai-summary
- Manage guest links → access-links
- Choose recording folder → drive-folder-select
- Organization settings → org-settings
- Platform console → platform-orgs
- Explore the product → landing
- Mentor home → mentor-dashboard
- Member home → student-dashboard

## A better place to work together (landing)
Section: Start · Type: dashboard

Welcome to Forma: a virtual workspace where teams meet, learn, and keep a clear view of attendance.

- Sign in → sign-in
- Accept an invitation → invite-accept
- Enter as a guest → guest-access
- Open demo overview → overview

## Welcome back (sign-in)
Section: Start · Type: form

Sign in with the phone number and password associated with your organization.

- Continue to demo overview → overview
- Forgot password? → forgot-password
- Use an invitation link → invite-accept
- Back to welcome → landing

## Reset your password (forgot-password)
Section: Start · Type: form

Enter your account phone number. For privacy, a real service should not reveal whether an account exists.

- Continue to verification → otp-verify
- Back to sign in → sign-in
- Return to welcome → landing

## Verify your phone (otp-verify)
Section: Start · Type: form

Enter the six-digit code sent to your phone to continue password recovery.

- Verify and set password → password-reset
- Back to phone number → forgot-password
- Return to sign in → sign-in

## Choose a new password (password-reset)
Section: Start · Type: form

Set a strong password for your account. A real product should enforce its published password policy.

- Save and sign in → sign-in
- Back to verification → otp-verify

## You're invited to Acme Studio (invite-accept)
Section: Start · Type: detail

Review the organization and role before accepting a time-limited invitation.

- Accept invitation → sign-in
- Invitation expired? → expired-link
- Back to welcome → landing

## Join as a guest (guest-access)
Section: Start · Type: form

Use a workspace-issued guest link to enter a public room with limited access.

- Preview guest workspace → office
- Link is private or unavailable → private-denied
- Link expired → expired-link
- Back to welcome → landing

## This space isn't available to guests (private-denied)
Section: Start · Type: empty

This workspace requires a member account or a guest link scoped to a public room.

- Sign in as a member → sign-in
- Try another guest link → guest-access
- Return to welcome → landing

## This link has expired (expired-link)
Section: Start · Type: empty

For security, workspace and invitation links can expire. Ask an organization admin for a fresh link.

- Contact an organization admin → members
- Sign in instead → sign-in
- Back to welcome → landing

## Acme Studio virtual office (office)
Section: Workspace · Type: office

A shared, navigable office with room occupancy, today's sessions, and collaboration controls.

- Join meeting room → meeting-prejoin
- Open focus room settings → room-settings
- Edit office map → office-map-editor
- View schedule → schedule
- Open messages and channels → messages-inbox
- Customize your avatar → avatar-theme
- Sync calendar → calendar-connect
- Back to overview → overview

## Office map editor (office-map-editor)
Section: Workspace · Type: office

Arrange rooms and shared areas, then preview the layout before publishing it to your organization.

- Save map draft → office
- Configure a room → room-settings
- Preview office → office

## Focus room settings (room-settings)
Section: Workspace · Type: form

Set a room's name, capacity, access, and availability so members know how to use it.

- Save room settings → office
- Edit map layout → office-map-editor
- Back to office → office

## Ready to join? (meeting-prejoin)
Section: Workspace · Type: meeting

Check the room and your device preferences before joining the scheduled meeting.

- Join meeting → meeting-live
- Review recording consent → recording-consent
- Return to office → office

## Design standup (meeting-live)
Section: Workspace · Type: meeting

A live-meeting layout with participants, call controls, consent state, and room information.

- Participant controls → participant-controls
- Start recording flow → recording-consent
- Share screen → screen-share
- Create AI summary and transcript → ai-summary
- End and return to office → office

## Recording consent (recording-consent)
Section: Workspace · Type: meeting

Make recording status and participant consent clear before a meeting is recorded.

- Continue to meeting controls → meeting-live
- Start recording after consent → recording-active
- Review participant status → participant-controls
- Cancel and leave → office

## People in this meeting (participant-controls)
Section: Workspace · Type: table

Review participant access, speaking status, and recording consent without exposing private data.

- Back to meeting → meeting-live
- Review consent → recording-consent
- See all members → members

## Share your screen (screen-share)
Section: Workspace · Type: meeting

Choose a share option and review who can see it before presenting in the meeting.

- Preview sharing state → meeting-live
- Check participant list → participant-controls
- Back to office → office

## Recording in progress (recording-active)
Section: Workspace · Type: meeting

Show a persistent recording indicator, elapsed time, consent coverage, and a clear stop action.

- Stop recording and review upload → recording-detail
- View participants → participant-controls
- Return to meeting → meeting-live

## People at Acme Studio (members)
Section: People · Type: table

Find people, review their organization role and team, and manage invitations from one directory.

- Invite a member → member-invite
- Open Olivia's member profile → member-detail
- Manage roles → roles
- Manage teams → teams
- Manage invitations and guest links → access-links
- Manage guest links → access-links
- Back to overview → overview

## Invite someone to Acme Studio (member-invite)
Section: People · Type: form

Choose a role and team, then send a time-limited invitation link to a new member.

- Preview invitation → invite-accept
- Review role permissions → roles
- Back to members → members

## Olivia Rhye (member-detail)
Section: People · Type: detail

A member profile with role, team, current status, and links to attendance and schedule context.

- View attendance history → attendance-member
- View weekly schedule → schedule
- Edit organization role → roles
- Back to directory → members

## Roles and permissions (roles)
Section: People · Type: table

Review the least-privilege capabilities available to organization admins, mentors, members, and guests.

- Invite with a role → member-invite
- Manage team assignments → teams
- Back to members → members

## Teams (teams)
Section: People · Type: table

Group members for shared schedules, reporting, and access to relevant workspaces.

- Create a team → team-create
- View member directory → members
- Review roles → roles

## Create a team (team-create)
Section: People · Type: form

Give a team a clear name, assign a lead, and select members for schedules and reporting.

- Save team → teams
- Back to teams → teams

## Weekly schedule (schedule)
Section: Attendance · Type: table

Plan recurring team sessions across the week with clear timezone and attendance expectations.

- Create a session → session-create
- Edit Design standup → session-edit
- Set holidays → holidays
- Request time off → leave-request
- Back to overview → overview

## Create a scheduled session (session-create)
Section: Attendance · Type: form

Set a one-off or recurring session, assign its audience and room, and define the attendance grace period.

- Save session → schedule
- Review attendance rules → org-policies
- Back to schedule → schedule

## Edit Design standup (session-edit)
Section: Attendance · Type: form

Update a scheduled session while reviewing who is affected and whether past attendance snapshots remain unchanged.

- Save changes → schedule
- View session attendance → attendance-session
- Back to weekly schedule → schedule

## Organization holidays (holidays)
Section: Attendance · Type: table

Mark organization-wide holidays so recurring sessions and attendance expectations are clear.

- Add a holiday → holiday-create
- Return to schedule → schedule
- Review organization policies → org-policies

## Add an organization holiday (holiday-create)
Section: Attendance · Type: form

Specify whether a date is a full or partial holiday and how recurring sessions should be handled.

- Save holiday → holidays
- Back to holidays → holidays

## Request time off (leave-request)
Section: Attendance · Type: form

Submit planned leave with dates and a reason so mentors and administrators can review schedule coverage.

- Submit leave request → leave-review
- View my schedule → personal-schedule
- Back to team schedule → schedule

## Leave request review (leave-review)
Section: Attendance · Type: detail

Review a pending leave request, check schedule conflicts, and record an auditable decision.

- Approve request → personal-schedule
- Review attendance context → attendance-member
- Return to schedule → schedule

## Attendance report (attendance-report)
Section: Attendance · Type: dashboard

Compare scheduled time with verified presence, punctuality, breaks, and reviewed exceptions.

- Open Phoenix's attendance → attendance-member
- View a session → attendance-session
- Review pending corrections → correction-queue
- Export report → attendance-export
- Configure notifications → attendance-notifications
- Mentor dashboard → mentor-dashboard
- Member dashboard → student-dashboard
- Back to overview → overview

## Phoenix Baker · attendance (attendance-member)
Section: Attendance · Type: detail

A member-level view of scheduled sessions, grace-adjusted arrival, confirmed connected time, and corrections.

- Request an attendance correction → correction-request
- Review pending correction → correction-queue
- Open session detail → attendance-session
- Back to attendance report → attendance-report

## Frontend mentorship · session detail (attendance-session)
Section: Attendance · Type: detail

Inspect scheduled start and end, attendance events, grace period, and documented session exceptions.

- Review correction queue → correction-queue
- Open member attendance → attendance-member
- Return to report → attendance-report

## Request an attendance correction (correction-request)
Section: Attendance · Type: form

Explain a missed or incorrect attendance event. Requests remain pending until an authorized reviewer decides.

- Submit for review → correction-queue
- View my attendance → attendance-member
- Back to report → attendance-report

## Attendance corrections (correction-queue)
Section: Attendance · Type: table

Review requested changes with their reason and original record. Approved edits should retain an audit trail.

- Review Phoenix's correction → correction-review
- View approved correction history → correction-approved
- Open session details → attendance-session
- Back to report → attendance-report

## Review Phoenix's correction (correction-review)
Section: Attendance · Type: detail

Compare the original verified event with the requested change, capture a reviewer reason, and decide fairly.

- Approve correction → correction-approved
- Return to correction queue → correction-queue
- Open member context → attendance-member

## Correction decision recorded (correction-approved)
Section: Attendance · Type: success

A confirmation view for the reviewed correction, including the recorded outcome and audit context.

- Return to correction queue → correction-queue
- View attendance report → attendance-report
- Open audit log → audit-log

## Export attendance report (attendance-export)
Section: Attendance · Type: form

Choose a date range, teams, and report fields before preparing a privacy-conscious attendance export.

- Preview export → attendance-report
- Configure report notifications → attendance-notifications
- Back to attendance report → attendance-report

## Attendance notifications (attendance-notifications)
Section: Attendance · Type: form

Choose which attendance events notify members, mentors, or administrators and how often summaries arrive.

- Save notification preferences → attendance-report
- Review organization policies → org-policies
- Back to report → attendance-report

## Mentor home (mentor-dashboard)
Section: Attendance · Type: dashboard

A focused view of assigned learners, today's sessions, and attendance follow-ups for a mentor.

- Review learner attendance → attendance-member
- Open today's schedule → personal-schedule
- Open shared office → office
- Back to overview → overview

## Your workspace (student-dashboard)
Section: Attendance · Type: dashboard

Members can see their own upcoming sessions, attendance progress, and requests without exposing peers' private records.

- Open my schedule → personal-schedule
- View my attendance → attendance-member
- Request a correction → correction-request
- Join the office → office
- Back to overview → overview

## My schedule (personal-schedule)
Section: Attendance · Type: table

A member or mentor view of assigned sessions, timezone, room, and approved time away.

- Request time off → leave-request
- Review my attendance → attendance-member
- Return to member home → student-dashboard
- Return to mentor home → mentor-dashboard

## Recording history (recordings)
Section: Recordings · Type: table

Follow meeting recordings from consent and processing through Drive upload, retry, and retention.

- Open Design standup recording → recording-detail
- Monitor upload progress → recording-uploading
- Review a failed upload → recording-failed
- Connect Google Drive → drive-connect
- Select recording folder → drive-folder-select
- Generate meeting notes → ai-summary
- Review storage usage → drive-quota
- Back to overview → overview

## Design standup · recording (recording-detail)
Section: Recordings · Type: detail

Review consent, processing status, destination, access, and retention for one meeting recording.

- Open recording history → recordings
- View upload details → recording-uploading
- Manage Drive connection → drive-connected
- Review retention policy → retention-policy

## Recording upload in progress (recording-uploading)
Section: Recordings · Type: detail

Show upload progress, retry-safe job status, destination folder, and the time of the last update.

- Return to recording history → recordings
- Review retryable failure state → recording-failed
- Check Drive connection → drive-connected

## Upload needs attention (recording-failed)
Section: Recordings · Type: detail

Explain a retryable upload error, protect the original recording, and show the next safe step.

- Reconnect Google Drive → drive-connect
- Review recording history → recordings
- Check storage quota → drive-quota

## Connect Google Drive (drive-connect)
Section: Recordings · Type: form

Choose an organization-owned Drive destination and review the requested access before connecting.

- Review Google access consent → drive-consent
- Choose Drive folder → drive-folder-select
- View recordings → recordings
- Review organization privacy settings → org-policies

## Review Drive access (drive-consent)
Section: Recordings · Type: detail

Explain the organization-controlled scope and destination before an administrator authorizes a Drive connection.

- Continue to connected state → drive-connected
- Cancel connection → drive-connect
- Review privacy policies → org-policies

## Google Drive connected (drive-connected)
Section: Recordings · Type: success

Review connection owner, selected folder, upload policy, and options to revoke access or inspect storage.

- View recording history → recordings
- Review storage quota → drive-quota
- Revoke connection → drive-revoked
- Review retention policy → retention-policy

## Drive connection revoked (drive-revoked)
Section: Recordings · Type: empty

Show the organization that new uploads are paused and recordings remain available for an authorized reconnect.

- Reconnect Drive → drive-connect
- Review paused recordings → recordings
- Review audit history → audit-log

## Recording storage usage (drive-quota)
Section: Recordings · Type: dashboard

Monitor organization recording storage, retention headroom, and the next action when a quota is near its limit.

- Review retention settings → retention-policy
- View recording history → recordings
- Manage billing plan → billing-plans
- Check Drive connection → drive-connected

## Organization settings (org-settings)
Section: Organization · Type: dashboard

Manage organization identity, workspace defaults, privacy policy, and operational controls.

- Edit attendance policies → org-policies
- Set recording retention → retention-policy
- Review audit log → audit-log
- Manage billing → billing-plans
- View usage → billing-usage
- Manage invitations and guest links → access-links
- Connect team calendar → calendar-connect
- AI meeting notes → ai-summary
- Back to overview → overview

## Attendance and workspace policies (org-policies)
Section: Organization · Type: form

Make attendance calculations, privacy expectations, and room access rules clear and consistent.

- Save policy draft → org-settings
- Review notification behavior → attendance-notifications
- Set recording retention → retention-policy
- Back to organization settings → org-settings

## Recording retention policy (retention-policy)
Section: Organization · Type: form

Define recording retention and deletion responsibilities with clear notice to members and auditors.

- Save retention draft → org-settings
- Review recording storage → drive-quota
- Review audit log → audit-log
- Back to settings → org-settings

## Organization audit log (audit-log)
Section: Organization · Type: table

Review sensitive organization changes with actor, timestamp, target, and an auditable reason.

- Review corrections → correction-queue
- Open organization policies → org-policies
- Return to organization settings → org-settings

## Plans for your organization (billing-plans)
Section: Organization · Type: table

Compare member and recording limits, then review a plan before continuing to a simulated checkout.

- Review Team plan checkout → billing-checkout
- View invoices → billing-invoices
- Review usage → billing-usage
- Back to organization settings → org-settings

## Review your Team plan (billing-checkout)
Section: Organization · Type: detail

Review plan limits and the illustrative billing summary before a simulated confirmation.

- Confirm demo plan → billing-success
- Compare plans → billing-plans
- Review invoices → billing-invoices

## Plan updated (billing-success)
Section: Organization · Type: success

Confirm the selected plan and provide a path to usage and invoice history.

- View invoices → billing-invoices
- Review plan usage → billing-usage
- Back to organization settings → org-settings

## Invoices and billing history (billing-invoices)
Section: Organization · Type: table

Review invoice dates, amounts, and payment status for the organization subscription.

- Review plans → billing-plans
- View plan usage → billing-usage
- Back to organization settings → org-settings

## Plan usage (billing-usage)
Section: Organization · Type: dashboard

Understand member, session, and recording usage before reaching a plan limit.

- Compare plans → billing-plans
- Review recording storage → drive-quota
- View invoices → billing-invoices
- Organization settings → org-settings

## Platform organizations (platform-orgs)
Section: Platform · Type: table

A restricted super-admin overview of tenant health, plan status, and support follow-ups.

- Open Acme Studio organization → platform-org-detail
- Create an organization → platform-org-create
- View platform health → platform-health
- Return to workspace → overview

## Acme Studio · platform view (platform-org-detail)
Section: Platform · Type: detail

Review tenant-level configuration and health metadata without opening member content or private recordings.

- Return to organization list → platform-orgs
- Open health dashboard → platform-health
- View organization audit log → audit-log

## Create an organization (platform-org-create)
Section: Platform · Type: form

Provision a new tenant with an explicit region, initial plan, and accountable organization owner.

- Preview organization setup → platform-org-detail
- Return to organization list → platform-orgs

## Platform health (platform-health)
Section: Platform · Type: dashboard

Review service availability and operational queue indicators without accessing customer content.

- Review organizations → platform-orgs
- Inspect Acme Studio health → platform-org-detail
- Return to overview → overview

## Messages and channels (messages-inbox)
Section: Workspace · Type: table

Bring team channels and recent conversations together. Choose a conversation to review its shared context.

- Open design conversation → message-conversation
- Start a channel conversation → message-conversation
- View the shared office → office
- Back to overview → overview

## # design-team (message-conversation)
Section: Workspace · Type: detail

A channel conversation view with recent messages, member context, and a composer for a simulated reply.

- Return to messages and channels → messages-inbox
- View team members → members
- Open the office → office

## Avatar and office appearance (avatar-theme)
Section: Workspace · Type: form

Choose an illustrative avatar, room theme, and furniture set to personalize your virtual office presence.

- Preview in the office → office
- Edit room layout → office-map-editor
- Back to overview → overview

## Connect Google Calendar (calendar-connect)
Section: Organization · Type: form

Review a simulated calendar connection and choose which team schedule may sync before opening the consent step.

- Review calendar access → calendar-connected
- Back to weekly schedule → schedule
- Organization settings → org-settings

## Calendar sync settings (calendar-connected)
Section: Organization · Type: success

Review a sample connected calendar, sync direction, last sync, and an option to disconnect or adjust scope.

- Adjust calendar access → calendar-connect
- Review weekly schedule → schedule
- Organization settings → org-settings

## Meeting summary and transcript (ai-summary)
Section: Recordings · Type: detail

Review a clearly labeled generated-notes preview alongside transcript excerpts, speaker labels, and timestamps.

- Open recording history → recordings
- Review recording consent → recording-consent
- Open transcript source details → recording-detail

## Invitations and guest links (access-links)
Section: People · Type: table

Review member invitations and scoped guest links, including expiry, access level, and revocation status.

- Create a guest link → access-link-create
- Revoke selected guest link → access-link-revoked
- Preview invitation acceptance → invite-accept
- Review role access → roles
- Back to members → members

## Create a guest access link (access-link-create)
Section: People · Type: form

Limit a guest link to a room and time window, and choose whether it may be used once or more than once.

- Create link and return to management → access-links
- Back to link management → access-links
- Review guest restrictions → private-denied

## Guest link revoked (access-link-revoked)
Section: People · Type: success

Confirm a link is no longer available and explain that revocation does not change a member account or existing recordings.

- Return to link management → access-links
- Create another guest link → access-link-create
- Review organization audit log → audit-log

## Select a Drive folder (drive-folder-select)
Section: Recordings · Type: table

Choose a destination folder with the narrowest suitable scope before continuing the organization Drive setup.

- Use selected folder → drive-connect
- Review Drive consent → drive-consent
- Return to recording history → recordings
